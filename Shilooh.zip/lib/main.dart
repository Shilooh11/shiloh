import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shiloh_app/scr/providers/auth_provider.dart';
import 'package:shiloh_app/scr/routes/app_routes.dart';
import 'package:shiloh_app/scr/routes/routes.dart';
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
            lazy: false, create: (_) => AuthProviderController()),
      ],
      child: MaterialApp(
        title: 'Shiloh',
        debugShowCheckedModeBanner: false,    
        initialRoute: Routes.login,
        routes: appRoutes,

      ),
    );
  }
}
