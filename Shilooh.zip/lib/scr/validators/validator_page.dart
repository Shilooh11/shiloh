class Validators {
  // PARA VALIDAR EMAIL
  static String? validateEmail(String? value) {
    if (value!.isEmpty) {
      return 'Ingresa un correo';
    }
    if (!value.contains('@')) {
      return "Tu correo debe tener '@'";
    }
    if (!RegExp(
      r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+",
    ).hasMatch(value)) {
      return "Ingrese un correo válido";
    }
    if (value.contains(' ')) {
      return "El correo no debe contener espacios";
    }
    return null;
  }

  //PARA VALIDAR CONTRASEÑA
  static String? validatePassword(String? value) {
    if (value!.isEmpty) {
      return 'La contraseña es obligatoria';
    }
    if (value.length < 8) {
      return 'La contraseña debe tener al menos 8 caracteres';
    }
    if (value.contains(' ')) {
      return "La contraseña no debe contener espacios";
    }
    return null;
  }

  //PARA VALIDAR NOMBRE
  static String? validateName(String? value) {
    if (value!.isEmpty) {
      return 'Ingresa tu nombre';
    }
    return null;
  }

  //PARA VALIDAR APELLIDOS
  static String? validateLastName(String? value) {
    if (value!.isEmpty) {
      return 'Ingresa tus apellidos';
    }
    return null;
  }

  //PARA VALIDAR FECHA DE NACIMIENTO
  static String? validateDate(String? value) {
    if (value!.isEmpty) {
      return 'Ingresa tu fecha de nacimiento';
    }
    //tiene que ser mayor de 12 años

    return null;
  }
}
