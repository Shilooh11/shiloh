import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shiloh_app/scr/utils/app_colors.dart';
import 'package:shiloh_app/scr/validators/validator_page.dart';
import 'package:shiloh_app/scr/widgets/imput_decoration_widget.dart';
import 'package:shiloh_app/scr/widgets/material_buttom_widget.dart';
import 'package:shiloh_app/scr/widgets/textbuttom_widget.dart';
import 'package:shiloh_app/scr/providers/auth_provider.dart';


class LoginView extends StatelessWidget {
  const LoginView({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final authProvider = Provider.of<AuthProviderController>(context);
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // SizedBox(height: 30),
              const Text(
                'Shiloh',
                style: TextStyle(
                  fontSize: 50,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: size.height * 0.01),
              // Imagen
              Padding(
                padding: EdgeInsets.symmetric(horizontal: size.width * 0.1),
                child: Image.asset(
                  'assets/pesas.png',
                  width: size.width * 0.8,
                ),
              ),
              SizedBox(height: size.height * 0.05),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Container(
                  decoration: BoxDecoration(
                    color: AppColors.black,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Form(
                      key: authProvider.formKeyLogin,
                      autovalidateMode: AutovalidateMode.onUserInteraction,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Text(
                            "Ingresa tu cuenta",
                            style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 20),
                          //email
                          ImputDecorationWidget(
                            controller: authProvider.emailController,
                            labelText: 'Ingresa tu correo',
                            hintText: "usuario@gmail.com",
                            prefixIcon: const Icon(Icons.email),
                            keyboardType: TextInputType.emailAddress,
                            validator: Validators.validateEmail,
                          ),
                          SizedBox(height: size.height * 0.03),
                          //Password
                          ImputDecorationWidget(
                            controller: authProvider.passwordController,
                            hintText: "**********",
                            labelText: 'Ingresa tu contraseña',
                            prefixIcon: const Icon(Icons.lock),
                            suffixIcon: IconButton(
                              icon: Icon(
                                authProvider.obscure
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                                color: AppColors.black,
                              ),
                              onPressed: () {
                                authProvider.toggleObscure();
                              },
                            ),
                            keyboardType: TextInputType.visiblePassword,
                            obscureText: authProvider.obscure,
                            validator: Validators.validatePassword,
                          ),
                          const SizedBox(height: 10.0),
                          //olvidaste tu contraseña?
                          TextbuttomWidget(
                              text: '¿Olvidaste tu contraseña?',
                              onPressed: () {
                                Navigator.pushNamed(context, '/forgot');
                              }),
                          const SizedBox(height: 0.01),
                          // no tienes una cuenta ?
                          TextbuttomWidget(
                            text: '¿No tienes una cuenta?',
                            onPressed: () {
                              Navigator.pushNamed(context, '/register');
                            },
                          ),
                          //button
                          MaterialButtomWidget(
                            text: "Iniciar sesión",
                            onPressed: () {
                              Navigator.pushNamed(context, '/home');

                            },
                          ),
                          const SizedBox(height: 5.0)
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
