import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shiloh_app/scr/utils/app_colors.dart';
import 'package:shiloh_app/scr/validators/validator_page.dart';
import 'package:shiloh_app/scr/widgets/imput_decoration_widget.dart';
import 'package:shiloh_app/scr/widgets/material_buttom_widget.dart';
import 'package:shiloh_app/scr/providers/auth_provider.dart';


class RegisterView extends StatefulWidget {
  const RegisterView({super.key});

  @override
  _RegisterViewState createState() => _RegisterViewState();
}

class _RegisterViewState extends State<RegisterView> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final authProvider = Provider.of<AuthProviderController>(context);
    return Scaffold(
        body: SingleChildScrollView(    
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: size.height * 0.05), 

          const Text(
            'Shiloh',
            style: TextStyle(
              fontSize: 50,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(height: size.height * 0.01),
          //Imagen
          Image.asset(
            'assets/pesas.png',
            width: size.width * 0.7,
          ),
          SizedBox(height: size.height * 0.01),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Form(
              key: authProvider.formKeyRegister,
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.black,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      const Text(
                        "Registrate para crear tu cuenta",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: size.height * 0.04),
                      //nombre
                      ImputDecorationWidget(
                        controller: authProvider.nameController,
                        labelText: 'Ingresa tu nombre',
                        hintText: "Nombre",
                        prefixIcon: const Icon(Icons.person),
                        keyboardType: TextInputType.text,
                        validator: Validators.validateName,
                      ),
                      SizedBox(height: size.height * 0.02),
                      //Apellidos
                      ImputDecorationWidget(
                        controller: authProvider.lastNameController,
                        labelText: 'Ingresa tus apellidos',
                        hintText: "Apellidos",
                        prefixIcon: const Icon(Icons.person),
                        keyboardType: TextInputType.text,
                        validator: Validators.validateLastName,
                      ),
                      SizedBox(height: size.height * 0.02),
                      //email
                      ImputDecorationWidget(
                        controller: authProvider.emailController,
                        labelText: 'Ingresa tu correo',
                        hintText: "usuario@gmail.com",
                        prefixIcon: const Icon(Icons.email),
                        keyboardType: TextInputType.emailAddress,
                        validator: Validators.validateEmail,
                      ),
                      SizedBox(height: size.height * 0.02),
                      //Password
                      ImputDecorationWidget(
                        controller: authProvider.passwordController,
                        hintText: "**********",
                        labelText: 'Ingresa tu contraseña',
                        prefixIcon: const Icon(Icons.lock),
                        suffixIcon: IconButton(
                          icon: Icon(
                            authProvider.obscure
                                ? Icons.visibility
                                : Icons.visibility_off,
                            color: AppColors.black,
                          ),
                          onPressed: () {
                            authProvider.toggleObscure();
                          },
                        ),
                        keyboardType: TextInputType.visiblePassword,
                        obscureText: authProvider.obscure,
                        validator: Validators.validatePassword,
                      ),
                      SizedBox(height: size.height * 0.02),
                      // Vuelva a escribir su contraseña
                      ImputDecorationWidget(
                        controller: authProvider.confirmPasswordController,
                        hintText: "**********",
                        labelText: 'Vuelva a escribir su contraseña',
                        prefixIcon: const Icon(Icons.lock),
                        keyboardType: TextInputType.visiblePassword,
                        obscureText: authProvider.obscure,
                        validator: Validators.validatePassword,
                      ),
                      SizedBox(height: size.height * 0.02),
                      //fecha
                      getBirth(authProvider, context),
                      SizedBox(height: size.height * 0.04),
                      MaterialButtomWidget(
                        text: "Registrarse",
                        onPressed: () {
                          //cerrar el teclado
                          FocusScope.of(context).unfocus();
                          //validar formulario
                          if (authProvider.formKeyRegister.currentState!
                              .validate()) {
                            //validar que las contraseñas sean iguales
                            if (authProvider.passwordController.text !=
                                authProvider.confirmPasswordController.text) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text("Las contraseñas no coinciden"),
                                ),
                              );
                              return;
                            }

                            print("formulario validado");
                          }
                        },
                      ),
                      SizedBox(height: size.height * 0.03),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: size.height * 0.03),
        ],
      ),
    ));
  }

  Widget getBirth(AuthProviderController authProvider, BuildContext context) {
    return ImputDecorationWidget(
        controller: authProvider.dateController,
        labelText: 'Fecha de nacimiento',
        hintText: "DD/MM/AAAA",
        prefixIcon: const Icon(Icons.calendar_today),
        keyboardType: TextInputType.datetime,
        readOnly: true,
        validator: Validators.validateDate,
        onTap: () async {
          DateTime? _pick = await showDatePicker(
            context: context,
            initialDate: DateTime.now(),
            firstDate: DateTime(1900),
            lastDate: DateTime(2025),
          );
          if (_pick != null) {
            //formate la fecha de 2024-10-12 a 12/10/2024

            final String date =
                "${_pick.toString().split(" ")[0].split("-")[2]}/"
                "${_pick.toString().split(" ")[0].split("-")[1]}/"
                "${_pick.toString().split(" ")[0].split("-")[0]}";

            setState(() {
              authProvider.dateController.text = date;
            });
          }
        });
  }
}
