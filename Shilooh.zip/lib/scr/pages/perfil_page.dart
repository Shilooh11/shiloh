import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shiloh_app/scr/providers/auth_provider.dart';
import 'package:shiloh_app/scr/validators/validator_page.dart';
import 'package:shiloh_app/scr/widgets/imput_decoration_widget.dart';
import 'package:shiloh_app/scr/widgets/row_image_perfil.dart';

class PerfilPage extends StatefulWidget {
  const PerfilPage({super.key});

  @override
  State<PerfilPage> createState() => _PerfilPageState();
}

class _PerfilPageState extends State<PerfilPage> {

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProviderController>(context);
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Column(
          children: [
            SizedBox(height: size.height * 0.06),
            const RowImagePerfil(image: "assets/egoista.jpg", name: "Alexander"),
            SizedBox(height: size.height * 0.04),
            ImputDecorationWidget(
              controller: authProvider.lastNameController,
              labelText: 'Ingresa tus apellidos',
              hintText: "Apellidos",
              prefixIcon: const Icon(Icons.person),
              keyboardType: TextInputType.text,
              validator: Validators.validateLastName,
            ),
            SizedBox(height: size.height * 0.02),
            //email
            ImputDecorationWidget(
              controller: authProvider.emailController,
              labelText: 'Ingresa tu correo',
              hintText: "usuario@gmail.com",
              prefixIcon: const Icon(Icons.email),
              keyboardType: TextInputType.emailAddress,
              validator: Validators.validateEmail,
            ),
            SizedBox(height: size.height * 0.02),
            //birth
            getBirth(authProvider, context),
          ],
        ),
      ),
    );
  }

  Widget getBirth(AuthProviderController authProvider, BuildContext context) {
    return ImputDecorationWidget(
        controller: authProvider.dateController,
        labelText: 'Fecha de nacimiento',
        hintText: "DD/MM/AAAA",
        prefixIcon: const Icon(Icons.calendar_today),
        keyboardType: TextInputType.datetime,
        readOnly: true,
        validator: Validators.validateDate,
        onTap: () async {
          DateTime? _pick = await showDatePicker(
            context: context,
            initialDate: DateTime.now(),
            firstDate: DateTime(1900),
            lastDate: DateTime(2025),
          );
          if (_pick != null) {
            //cambiar formato de 2024-10-12 a 12/10/2024

            final String date =
                "${_pick.toString().split(" ")[0].split("-")[2]}/"
                "${_pick.toString().split(" ")[0].split("-")[1]}/"
                "${_pick.toString().split(" ")[0].split("-")[0]}";

            setState(() {
              authProvider.dateController.text = date;
            });
          }
        });
  }
}
