import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shiloh_app/scr/utils/app_colors.dart';
import 'package:shiloh_app/scr/widgets/material_buttom_widget.dart';
import 'package:table_calendar/table_calendar.dart';


class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  DateTime _focusedDay = DateTime.now();
  DateTime _selectedDay = DateTime.now();
  Map<String, dynamic> _ejercicios = {};

  @override
  void initState() {
    super.initState();
    _loadEjercicios();
  }

  // Json
  Future<void> _loadEjercicios() async {
    final String data = await rootBundle.loadString('assets/ejercicios.json');
    final Map<String, dynamic> ejercicios = json.decode(data);
    setState(() {
      _ejercicios = ejercicios;
    });
    print("Ejercicios: $_ejercicios");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 30),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.asset(
                      'assets/egoista.jpg',
                      width: 40,
                    ),
                    
                  ),
                  const SizedBox(width: 10),
                  RichText(
                      text: const TextSpan(
                    text: 'Hola, ',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                    ),
                    children: [
                      TextSpan(
                        text: 'Alexander',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  )),
                ],
              ),
            ),
            const SizedBox(height: 20),
            TableCalendar(
              firstDay: DateTime.utc(2023, 01, 01),
              lastDay: DateTime.utc(2100, 12, 30),
              focusedDay: _focusedDay,
              // siempre en formato de semana
              calendarFormat: CalendarFormat.week,
              availableCalendarFormats: const {
                // solo permitir el formato de semana
                CalendarFormat.week: 'week'
              },
              selectedDayPredicate: (day) {
                return isSameDay(_selectedDay, day);
              },
              onDaySelected: (selectedDay, focusedDay) {
                setState(() {
                  _selectedDay = selectedDay;
                  _focusedDay = focusedDay;
                });
              },
              onPageChanged: (focusedDay) {
                _focusedDay = focusedDay;
              },
            ),

            
        const SizedBox(height: 20),
            Container(
              height: 250,
              child: PageView.builder(
                itemCount: _ejercicios.keys.length,
                itemBuilder: (context, index) {
                  // Obtiene el día (Dia1, Dia2, etc.)
                  String dia = _ejercicios.keys.elementAt(index);
                  // Obtiene los ejercicios de ese día
                  Map<String, dynamic> ejerciciosPorDia = _ejercicios[dia];
                  return Card(
                    color: AppColors.black,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Stack(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Align(
                            alignment: Alignment.bottomRight,
                            child: MaterialButtomWidget(
                              onPressed: () {},
                              text: "Comenzar",
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                dia, // Muestra el día
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Expanded(
                                child: ListView.builder(
                                  itemCount: ejerciciosPorDia.keys
                                      .length, // Cantidad de categorías de ejercicios
                                  itemBuilder: (context, indexCategoria) {
                                    String categoria = ejerciciosPorDia.keys
                                        .elementAt(
                                            indexCategoria); // Obtiene la categoría (Pecho, Triceps, etc.)
                                    List<String> ejercicios =
                                        ejerciciosPorDia[categoria].cast<
                                            String>(); // Obtiene los ejercicios de esa categoría
                                    return Padding(
                                      padding: const EdgeInsets.only(top: 8.0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            categoria +
                                                ":", // Muestra la categoría
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          ...ejercicios
                                              .map((ejercicio) => Text(
                                                    " . $ejercicio", // Muestra cada ejercicio precedido por un punto
                                                    style: const TextStyle(
                                                      color: Colors.white,
                                                    ),
                                                  ))
                                              .toList(),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ), 
            const Align(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: EdgeInsets.all(8.0),
                child: Text(
                  "Estadisticas",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 25,
                  ),
                ),
              ),
            ),
            // Tiempo de sueño y calorias consumidas
            Expanded(
              child: SizedBox(
                child: ListView.builder(
                  itemCount: 3,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    return Container(
                      width: 150,
                      child: Card(
                        color: AppColors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Padding(
                          padding: EdgeInsets.all(10.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                "Tiempo de sueño",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              SizedBox(height: 10),
                              Text(
                                "Calorias sonsumibles",
                                style: TextStyle(
                                  color: Colors.white,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
