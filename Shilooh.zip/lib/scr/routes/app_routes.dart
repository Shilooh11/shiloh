import 'package:flutter/material.dart';
import 'package:shiloh_app/scr/pages/home_page.dart';
import 'package:shiloh_app/scr/pages/login.dart';
import 'package:shiloh_app/scr/pages/perfil_page.dart';
import 'package:shiloh_app/scr/pages/register.dart';
import 'package:shiloh_app/scr/routes/routes.dart';


Map<String, Widget Function(BuildContext)> appRoutes = {
  Routes.home: (context) => const HomePage(),
  Routes.login: (context) => const LoginView(),
  Routes.register: (context) => const RegisterView(),
  Routes.perfil: (context) => const PerfilPage(),
};
