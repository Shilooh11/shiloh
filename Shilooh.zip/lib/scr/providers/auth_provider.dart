import 'package:flutter/material.dart';

class AuthProviderController extends ChangeNotifier {
  GlobalKey<FormState> formKeyLogin = GlobalKey<FormState>();
  GlobalKey<FormState> formKeyRegister = GlobalKey<FormState>();

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController dateController = TextEditingController();

  bool isObscure = true;
  bool get obscure => isObscure;

  void toggleObscure() {
    isObscure = !isObscure;
    notifyListeners();
  }

}
  