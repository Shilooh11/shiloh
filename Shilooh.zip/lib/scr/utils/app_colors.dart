import 'package:flutter/material.dart';

class AppColors {
  static const pink = Color(0xff894BB9);
  static const black = Color(0xff000000);
  static const white = Color(0xffFFFFFF);
  static const fondo = Color(0xffF4EFEF);
}
