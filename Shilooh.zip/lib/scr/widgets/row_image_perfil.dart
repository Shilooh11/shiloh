import 'package:flutter/material.dart';

class RowImagePerfil extends StatelessWidget {
  final String image;
  final String name;
  final bool isEdit;
  final VoidCallback? onTap;
  const RowImagePerfil({
    super.key,
    required this.image,
    required this.name,
    this.isEdit = false,
    this.onTap,
  });
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0),
      child: Row(
        children: [
          InkWell(
            //si isEdit es true, se habilita el onTap
            onTap: isEdit ? onTap : null,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.asset(
                image,
                width: 40,
              ),
            ),
          ),
          const SizedBox(width: 10),
          RichText(
              text: TextSpan(
            text: 'Hola, ',
            style: const TextStyle(
              fontSize: 20,
              color: Colors.black,
            ),
            children: [
              TextSpan(
                text: name,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ],
          )),
        ],
      ),
    );
  }
}
