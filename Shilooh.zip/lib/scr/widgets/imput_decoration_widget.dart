import 'package:flutter/material.dart';
import 'package:shiloh_app/scr/utils/app_colors.dart';


class ImputDecorationWidget extends StatelessWidget {
  final String labelText;
  final String hintText;
  final bool filled;
  final Icon? prefixIcon;
  final Widget? suffixIcon;
  final TextInputType keyboardType;
  final bool obscureText;
  final int maxLines;
  final TextEditingController controller;
  final String? Function(String?)? validator;
  final void Function()? onTap;
  final bool readOnly;
  const ImputDecorationWidget({
    super.key,
    required this.labelText,
    required this.hintText,
    this.filled = true,
    this.prefixIcon,
    this.suffixIcon,
    required this.keyboardType,
    this.obscureText = false,
    this.maxLines = 1,
    required this.controller,
    required this.validator,
    this.onTap,
    this.readOnly = false,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      keyboardType: keyboardType,
      obscureText: obscureText,
      maxLines: maxLines,
      controller: controller,
      validator: validator,
      onTap: onTap,
      readOnly: readOnly,
      style: const TextStyle(fontFamily: ""),
      decoration: InputDecoration(
        labelText: labelText,
        hintText: hintText,
        hintStyle: TextStyle(color: AppColors.black.withOpacity(0.3)),
        labelStyle: const TextStyle(color: AppColors.pink),
        filled: filled,
        prefixIcon: prefixIcon,
        suffixIcon: suffixIcon,
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.black),
          borderRadius: BorderRadius.circular(20),
        ),
        // focusedBorder: OutlineInputBorder(
        //   borderSide: const BorderSide(color: Colors.black),
        //   borderRadius: BorderRadius.circular(20),
        // ),
        // errorBorder: OutlineInputBorder(
        //   borderSide: const BorderSide(color: Colors.red),
        //   borderRadius: BorderRadius.circular(20),
        // ),
        // border: OutlineInputBorder(
        //   borderSide: const BorderSide(color: Colors.black),
        //   borderRadius: BorderRadius.circular(20),
        // ),
      ),
    );
  }
}
